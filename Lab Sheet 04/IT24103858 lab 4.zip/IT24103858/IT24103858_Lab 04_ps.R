setwd("C:\\Users\\IT24103858\\Desktop\\IT24103858")
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")
fix(branch_data)
attach(branch_data)

str(branch_data)

boxplot(Sales_X1, main = "Box Plot for Sales", outline = TRUE, horizontal = TRUE)

summary(Advertising_X2)
IQR(Advertising_X2)

get.outliers <- function(z) {
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  ub <- q3 + 1.5 * iqr
  lb <- q1 - 1.5 * iqr
  print(paste("Upper Bound =", round(ub, 2)))
  print(paste("Lower Bound =", round(lb, 2)))
  outliers <- z[z < lb | z > ub]
  if (length(outliers) == 0) {
    print("No outliers found")
  } else {
    print(paste("Outliers:", paste(sort(outliers), collapse = ", ")))
  }
}

get.outliers(Years_X3)