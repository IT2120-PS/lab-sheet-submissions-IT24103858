#01
x <- c(1, 2, 3)
x[1] / x[2]^3 - 1 + 2 * x[3] - x[2 - 1]

#02
sum((1:15) %% 3 == 0)

#03
vec <- c(10, 45, 23, 99, 56)
max_index <- 1
for (i in 2:length(vec)) {
  if (vec[i] > vec[max_index]) {
    max_index <- i
  }
}
max_index

#04
which.max(vec)



